package com.ecommerce.EcomProj.Model;

public enum AppRoles {
    ROLES_USER,
    ROLES_ADMIN,
    ROLES_SELLER
}
