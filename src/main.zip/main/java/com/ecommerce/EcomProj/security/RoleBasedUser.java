package com.ecommerce.EcomProj.security;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.stereotype.Component;

@Component
public class RoleBasedUser {

    public UserDetailsService roleBasedUserDetailsService() {
        UserDetails user1 = User.withUsername("user")
                .password("{noop}user1")
                .roles("USER")
                .build();

        UserDetails admin = User.withUsername("admin")
                .password("{noop}admin1")
                .roles("ADMIN")
                .build();

        UserDetails user3 = User.withUsername("user2")
                .password("{noop}user2")
                .roles("USER", "ADMIN")
                .build();

        return new InMemoryUserDetailsManager(user1, admin, user3);
    }
}
