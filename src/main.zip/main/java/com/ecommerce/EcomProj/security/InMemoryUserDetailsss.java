package com.ecommerce.EcomProj.security;


import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.stereotype.Component;

@Component
public class InMemoryUserDetailsss {

    public UserDetailsService userDetailsService() {
        UserDetails user1 = User.withUsername("user")
                .password("{noop}user1").build();

        UserDetails user2 = User.withUsername("user2")
                .password("{noop}user2").build();

        UserDetails user3 = User.withUsername("user3")
                .password("{noop}user3").build();

        return new InMemoryUserDetailsManager(user1, user2, user3);
    }

}
