package com.ecommerce.EcomProj.security;

import com.ecommerce.EcomProj.security.jwt.AuthTokenFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.sql.DataSource;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
//    @Autowired
//    InMemoryUserDetailsss inMemoryUserDetailsss;
//
//    @Autowired
//    RoleBasedUser roleBasedUser;

    @Autowired
    DataSource dataSource;


    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http, AuthTokenFilter authTokenFilter) throws Exception {
        http.csrf(csrf->csrf.disable())
                .authorizeHttpRequests(authorizeRequests ->
                                authorizeRequests.requestMatchers("/admin/**").hasRole("ADMIN")
                                .requestMatchers("/user/**").hasAnyRole("USER", "ADMIN")
                                .requestMatchers("/signin").permitAll()
                                .anyRequest().authenticated());

//        http.httpBasic(Customizer.withDefaults());
//        http.formLogin(Customizer.withDefaults());

        http.addFilterBefore(authTokenFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

//    @Bean
//    public UserDetailsService getInMemoryUserDetailsss() {
//        return inMemoryUserDetailsss.userDetailsService();
//    }

//    @Bean
//    public UserDetailsService getRoleBasedUser() {
//        return roleBasedUser.roleBasedUserDetailsService();
//    }


    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }


    @Bean
    public UserDetailsService userDetailsService(DataSource dataSource,
                                                 PasswordEncoder passwordEncoder) {

        JdbcUserDetailsManager manager =
                new JdbcUserDetailsManager(dataSource);

        if (!manager.userExists("user")) {
            manager.createUser(
                    User.withUsername("user")
                            .password(passwordEncoder.encode("user1"))
                            .roles("USER")
                            .build()
            );
        }

        if (!manager.userExists("admin")) {
            manager.createUser(
                    User.withUsername("admin")
                            .password(passwordEncoder.encode("admin1"))
                            .roles("ADMIN")
                            .build()
            );
        }

        if (!manager.userExists("user2")) {
            manager.createUser(
                    User.withUsername("user2")
                            .password(passwordEncoder.encode("user2"))
                            .roles("USER", "ADMIN")
                            .build()
            );
        }

        if (!manager.userExists("admin2")) {
            manager.createUser(
                    User.withUsername("admin2")
                            .password(passwordEncoder.encode("admin2"))
                            .roles("ADMIN")
                            .build()
            );
        }


        return manager;
    }


    @Bean
    public AuthenticationManager authenticationManagerBean(AuthenticationConfiguration builder) throws Exception {
        return builder.getAuthenticationManager();
    }




}
